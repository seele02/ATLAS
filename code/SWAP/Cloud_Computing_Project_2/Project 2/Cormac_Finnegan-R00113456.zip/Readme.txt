This program is my submission for my second assignment in Cloud Computing and Python. It is a program that allows the automation and management of various cloud services.


*********************************************
				How to Run
*********************************************

The main functionality is accessed via the index.py file. Simply open and run this index file in the same directory as the other files in this folder.